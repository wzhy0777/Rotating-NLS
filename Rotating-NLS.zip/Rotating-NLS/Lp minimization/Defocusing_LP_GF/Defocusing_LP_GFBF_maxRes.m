clc;clear;tic;

%% ģ�Ͳ���
gamma_x=1; gamma_y=1;
V=@(x,y) 0.5*(gamma_x^2*x.^2+gamma_y^2*y.^2);

beta = 100;
p = 3;
w = -10; 
Omega = 0.5;

%% �������?
L = 20;
ax = -L; bx = L;
ay = -L; by = L;
Nx = 2^8; Ny = Nx;


u0_a = @(x,y) exp(-(x.^2+y.^2)/2)/(pi^.5);
u0_b = @(x,y) (x+1i*y).*u0_a(x,y); 
u0_c = @(x,y) ((x+1i*y).^4).*u0_a(x,y); 
u0_d = @(x,y) (u0_a(x,y)+(x+1i*y).*u0_a(x,y))/2;
u0_e = @(x,y) (1-Omega).*u0_a(x,y) + (Omega).*u0_b(x,y);
u0_f = @(x,y) (Omega).*u0_a(x,y) + (1-Omega).*u0_b(x,y);
u0_g = @(x,y) (Omega).*u0_a(x,y) + (1-Omega).*u0_c(x,y);

u0 = u0_c;



dt = .1;
maxit = 20000000;
tole = 1e-12; % 
 tolr = 1e-6; % 
 
 %% 
hx = (bx-ax)/Nx; hy = (by-ay)/Ny;
x = ax:hx:bx; y = ay:hy:by;
x = x(1:Nx)'; y = y(1:Ny)';
[X,Y] = meshgrid(x,y);

V = V(X,Y);
u0 = u0(X,Y);
%u0 = conj(u0);

%% ���帨����


up =  (2*pi/(bx-ax))*([0:(Nx/2-1),-Nx/2:-1]');
uq =  (2*pi/(by-ay))*([0:(Ny/2-1),-Ny/2:-1]');
[UP,UQ] = meshgrid(up,uq);
mu2 = (UP.^2+UQ.^2);
Laplacian = @(u) ifft2(-mu2.*fft2(u));


Ae = hx*hy;
Ih = @(U) Ae*sum(sum(U)); 
nrm_p = @(U) (Ih(abs(U).^(p+1))).^(1/(p+1)); 
nrm_max = @(U) max(abs(U(:)));

%% 
U = u0/nrm_p(u0);
n = 0;
S_phi_n = zeros(maxit,1); 
Res_phin = zeros(maxit,1); 
Err_Sn = zeros(maxit,1); 
while n < maxit
    U_old = U;
    
    
    Dxx = -.5*Laplacian(U);  
    LzU = 1i* ( Y.*ifft2(1i*UP.*fft2(U)) - X.*ifft2(1i*UQ.*fft2(U)) ); 
    DQ = Dxx + (V+w).*U - Omega.*LzU;
    QU = real( Ih(conj(U).*DQ) ); 
    S_phi_n(n+1) = (p-1)/(p+1)*(-beta)*(-QU/beta)^((p+1)/(p-1));
    
 
    lam = QU; 
    
    sigma = (-QU/beta)^(1/(p-1));

    Res_phin(n+1) = nrm_max(sigma*DQ + beta*abs(sigma*U).^(p-1).*(sigma*U)); 
    

    
     if n == 0
        Err_Sn(n+1) = 1e10;  
    else
        Err_Sn(n+1) = S_phi_n(n+1)-S_phi_n(n);
     end
    
     Bn = V+w-lam*abs(U).^(p-1);
     alfa = .5*max([0,max(max(Bn(:)+abs(Omega)^2*L^2))]) + 1;
     
     U1 = ifft2(   fft2(     (1+dt*alfa)*U -dt*(Bn.*U -Omega*LzU )   )  ./  (1+dt*(alfa+mu2/2))  );
     U  = U1 / nrm_p(U1);

    

     
%       if  (n < 30)  || (~mod(n,200))
%           disp([n         S_phi_n(n+1)        Err_Sn(n+1)  ] );
% 
% 
% 
%       end
     
     % if  (n < 30)  || (~mod(n,200))
%      if n<100000
%           disp([n         S_phi_n(n+1)        Err_Sn(n+1)  ] );
%           figure (1)
%           pcolor(X,Y,(abs(U)).^2);
%           colorbar;
%           shading interp;  colormap jet;
% 
%           drawnow;
%       end
% 
%       if (n < 10) || (~mod(n,20))
%           if n>0
%               fprintf('n: %d, maxres: %1.2E, action: %1.15f, ErrS: %1.2E\n',...
%                       (n+1),Res_phin(n+1),S_phi_n(n+1),Err_Sn(n+1));
%           end
%           figure (1)
%           pcolor(X,Y,(abs(U)).^2);
%           colorbar;
%           shading interp;  colormap jet;
% 
%           drawnow;
%       end
      
            if Res_phin(n+1)< tolr
         flag_Res = 1;
     else
         flag_Res = 0;
      end
      

     
     if ( flag_Res)
        break
     end
    
    n = n + 1;
    
end

iter = n+1;
U = U_old;

%% ���?
sigma = (-QU/beta)^(1/(p-1));
phi = sigma*U;

phi = [phi; phi(1,:)];
phi = [phi, phi(:,1)];
S_phi = (p-1)/(p+1)*(-beta)*(-QU/beta)^((p+1)/(p-1));


flag = 1;
if iter == maxit  % 
    flag = 0;
end

  fprintf('n: %d, maxres: %1.2E, action: %1.15f, ErrS: %1.2E\n',...
                      (n+1),Res_phin(n+1),S_phi_n(n+1),(S_phi_n(n+1)-S_phi_n(n)));
toc;