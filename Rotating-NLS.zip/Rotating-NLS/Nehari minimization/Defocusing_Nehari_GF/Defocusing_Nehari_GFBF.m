clc;clear;tic

%% 
gamma_x=1; gamma_y=1;
V=@(x,y) 0.5*(gamma_x^2*x.^2+gamma_y^2*y.^2);

beta = 100;
p = 3;
w = -30; 
Omega = 0.5;

%% 
L = 20;
ax = -L; bx = L;
ay = -L; by = L;
Nx = 2^8; Ny = Nx;

dt = .1;
maxit = 1e7;
tole = 1e-12; % 
 tolr = 1e-6; % 

u0_a = @(x,y) exp(-(x.^2+y.^2)/2)/(pi^.5);
u0_b = @(x,y) (x+1i*y).*u0_a(x,y); 
u0_c = @(x,y) ((x+1i*y).^4).*u0_a(x,y); 
u0_d = @(x,y) (u0_a(x,y)+(x+1i*y).*u0_a(x,y))/2;
u0_e = @(x,y) (1-Omega).*u0_a(x,y) + (Omega).*u0_b(x,y);
u0_f = @(x,y) (Omega).*u0_a(x,y) + (1-Omega).*u0_b(x,y);
u0_g = @(x,y) (Omega).*u0_a(x,y) + (1-Omega).*u0_c(x,y);
u0 = u0_d;







hx = (bx-ax)/Nx; hy = (by-ay)/Ny;
x = ax:hx:bx; y = ay:hy:by;
x = x(1:Nx)'; y = y(1:Ny)';
[X,Y] = meshgrid(x,y);

V = V(X,Y);
u0 = u0(X,Y);

%% 

%
up =  (2*pi/(bx-ax))*([0:(Nx/2-1),-Nx/2:-1]');
uq =  (2*pi/(by-ay))*([0:(Ny/2-1),-Ny/2:-1]');
[UP,UQ] = meshgrid(up,uq);
mu2 = (UP.^2+UQ.^2);
Laplacian = @(u) ifft2(-mu2.*fft2(u));


Ae = hx*hy;
Ih = @(U) Ae*sum(sum(U)); 
nrm_max = @(U) max(abs(U(:)));
nrm_p = @(U) (Ih(abs(U).^(p+1))).^(1/(p+1)); 

%% 
n = 0;

[dxx,rot]=dxx_rot(u0,mu2,Omega,X,Y,UP,UQ);
lll = Sigma(u0,dxx,rot,V,beta,p,w,hx,hy,Omega);
U = lll.*u0;



[dxx1,rot1]=dxx_rot(U,mu2,Omega,X,Y,UP,UQ);
K_constru0 = K_constr(U,dxx1,rot1,V,beta,p,w,hx,hy);




S_phin = zeros(maxit,1);  
Res_Seln = zeros(maxit,1); 
Err_Sn = zeros(maxit,1); 
K_n = zeros(maxit,1);


while n < maxit
    U_old = U;
    
    
    Dxx = -.5*Laplacian(U);  
    DFTu = fft2(U);
    LzU = 1i* ( Y.*ifft2(1i*UP.*DFTu) - X.*ifft2(1i*UQ.*DFTu) ); 
    DQ = Dxx + (V+w).*U - Omega*LzU;
    QU = real( Ih(conj(U).*DQ) ); 
    S_phin(n+1) = QU + 2*beta/(p+1)*Ih(abs(U).^(p+1));
    
    Res_Seln(n+1) = nrm_max(DQ + beta*abs(U).^(p-1).*U); 
    
     if n == 0
        Err_Sn(n+1) = 1e10;  
    else
        Err_Sn(n+1) = S_phin(n+1)-S_phin(n);
     end
     
    ds = Dxx + (w+V).*U  - Omega*LzU;
    gradient_K =  ds + 0.5*(p+1).*beta*abs(U).^(p-1).*U ;
    H_phi =  ds + beta*abs(U).^(p-1).*U;
    lamda1 = Ih(real(conj(gradient_K).*H_phi));
    lamda2 = Ih(gradient_K.*conj(gradient_K));
    lamda = lamda1/lamda2;
     
      
    Bn = V + w + beta*abs(U).^(p-1) - lamda.*gradient_K;
    alfa = .5*max([max(max(Bn+abs(Omega)^2*L^2)), 0])+1;
    
    U = ifft2((1+dt*(alfa+mu2/2)).\fft2( (1+dt*alfa)*U-dt*(Bn.*U -Omega*LzU ) ) );
    

    
    [dxx,rot]=dxx_rot(U,mu2,Omega,X,Y,UP,UQ);
    lll = Sigma(U,dxx,rot,V,beta,p,w,hx,hy,Omega);
    U = lll.*U;
    
[dxx2,rot2]=dxx_rot(U,mu2,Omega,X,Y,UP,UQ);
K_n(n+1) = K_constr(U,dxx2,rot2,V,beta,p,w,hx,hy) ;


    

%     
%     if (n < 10) || (~mod(n,200))
%          fprintf('n: %d, maxres: %1.2E, action: %1.15f, ErrS: %1.2E\n',...
%            n,Res_Seln(n+1),S_phin(n+1), Err_Sn(n+1) );
%         figure (1)
%         pcolor(X,Y,(abs(U)).^2);
%         colorbar;
%         shading interp;  colormap jet;
% 
%         drawnow;
%     end
     
     if  Res_Seln(n+1) < tolr 
        break
    end
    
    n = n + 1;
    
end

 fprintf('n: %d, maxres: %1.2E, action: %1.15f, ErrS: %1.2E\n',...
            n,Res_Seln(n+1),S_phin(n+1), Err_Sn(n+1) );
        toc;

iter = n;
U = U_old;

phi = U;
phi = [phi; phi(1,:)];
phi = [phi, phi(:,1)];

flag = 1;
if iter == maxit  % 
    flag = 0;
end



figure(1);
hx = (bx-ax)/Nx; hy = (by-ay)/Ny;
x = (ax:hx:bx)'; y = (ay:hy:by)';
[X,Y] = meshgrid(x,y);
pcolor(X,Y,abs(phi).^2);
shading interp; colorbar; colormap jet;

