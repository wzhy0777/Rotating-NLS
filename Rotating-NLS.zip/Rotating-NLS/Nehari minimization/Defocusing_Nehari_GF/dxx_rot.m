function [dxx,rx]=dxx_rot(U,mu2,Omega,X,Y,UP,UQ)

% dx=ifft2(diag(1i*up)*fft2(f1));
% dy=ifft2(fft2(f1)*diag(1i*uq));
% 
% dxx=-0.5*ifft2(-mu2.*fft2(f1));
% rx=-1i*Omega*(-diag(xi)*dy+dx*diag(yj));


Lzu = 1i* ( Y.*ifft2(1i*UP.*fft2(U)) - X.*ifft2(1i*UQ.*fft2(U)) );
rx = - Omega*Lzu;
dxx = -.5*ifft2(-mu2.*fft2(U));