function [sigma]=Sigma(U,dxx,rot,V,beta,p,w,hx,hy,Omega)

Ae = hx*hy;
Ih = @(U) Ae*sum(sum(U)); 
nrm_p = @(U) (Ih(abs(U).^(p+1))).^(1/(p+1)); 


dq = dxx + (V+w).*U + rot;
K1 = real( Ih(conj(U).*dq) );
K2 = beta.*(nrm_p(U)).^(p+1);
sigma = (-K1./K2)^(1/(p-1));