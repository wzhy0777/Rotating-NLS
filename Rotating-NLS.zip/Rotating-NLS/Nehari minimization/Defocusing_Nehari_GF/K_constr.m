function [K_constraint]=K_constr(f1,dxx,rot,v,beta,p,w,hx,hy)

hp1=real(dxx.*conj(f1))+(w+v).*(f1.*conj(f1))+real(rot.*conj(f1));
hp2=abs(f1).^(p+1);
ff0=hx*hy*sum(sum(hp1));
ff1=hx*hy*sum(sum(hp2));

K_constraint=ff0+beta*ff1;



%res=dxx+(w+v).*f1-rot+beta*abs(f1).^(p-1).*f1;

%U = f1;
%DQQ = -.5*Laplacian(U) + (V+w).*U - Omega*(1i* ( Y.*ifft2(1i*UP.*fft(U)) - X.*ifft2(1i*UQ.*fft(U)) ));
%  disssu0 =  real( Ih(conj(U).*DQQ) ) + beta * nrm_p(U).^(p+1) 